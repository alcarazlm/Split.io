import React from 'react'

const TextBox = () => {
    return (
        <div className='text-box'>
            <p> Split.io helps use OCR to parse receipts and easily drag and drop your items so you can easily split bills with friends!
        </p>
        </div>
    )
}

export default TextBox;