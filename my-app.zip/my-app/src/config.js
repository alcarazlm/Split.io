const firebaseConfig = {
    apiKey: "AIzaSyAD5GQ5ic_EtQCpVs6Hxnp8Ft2Qf3ODQF4",
    authDomain: "splitapp-20ec1.firebaseapp.com",
    projectId: "splitapp-20ec1",
    storageBucket: "splitapp-20ec1.appspot.com",
    messagingSenderId: "678033813527",
    appId: "1:678033813527:web:66483c9bc868dde211ac52",
    measurementId: "G-4ZFD0SX7KS",
    databaseURL: 'https://splitapp-20ec1-default-rtdb.firebaseio.com/'
  };
  
  
  export default firebaseConfig;